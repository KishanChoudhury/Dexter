README for RATP DECODA conversations (test data)

There are different versions provided for both English (EN) and French (FR) conversations

manual (47): manually translated dialogs
auto (53): automatically translated dialogs

Each of the versions contains 3 folders:

1. folders:
	text  original annotated translations (with punctuation and case inserted by the translators)
	trs   transcriptions (generated from text for English)

