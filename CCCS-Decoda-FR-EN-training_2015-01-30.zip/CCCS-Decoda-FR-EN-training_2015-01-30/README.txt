README for RATP DECODA conversations

There are different versions provided for both English (EN) and French (FR) conversations

auto_no_synopses (1000): automatically translated dialogs without synopses
manual (100): manually translated dialogs and synopses

Note that unlike the italian data, there are no automatically translated synopses.

Each of the versions contains 3 folders:

1. folders:
	text  original annotated translations (with punctuation and case inserted by the translators)
	trs   transcriptions (generated from text for English)
	synopses 

2. Synopsis files each contain up to 5 synopses by different annotators as 1 synopsis per line.
Each synopsis has 3 columns: filename, annotator id, and text.
