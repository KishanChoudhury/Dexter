namespace Microsoft.ProjectOxford.TextAnalytics.Contract.LanguageRequest
{
    public class Document
    {
        public string id { get; set; }
        public string text { get; set; }
    }
}