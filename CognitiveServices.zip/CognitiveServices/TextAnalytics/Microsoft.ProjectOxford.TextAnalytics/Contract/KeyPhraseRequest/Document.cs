﻿namespace Microsoft.ProjectOxford.TextAnalytics.Contract.KeyPhraseRequest
{
    public class Document
    {
        public string id { get; set; }
        public string text { get; set; }
    }
}
