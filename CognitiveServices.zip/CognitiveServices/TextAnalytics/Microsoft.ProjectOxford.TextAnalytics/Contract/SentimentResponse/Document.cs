﻿namespace Microsoft.ProjectOxford.TextAnalytics.Contract.SentimentResponse
{

    public class Document
    {
        public double score { get; set; }
        public string id { get; set; }
    }
}
