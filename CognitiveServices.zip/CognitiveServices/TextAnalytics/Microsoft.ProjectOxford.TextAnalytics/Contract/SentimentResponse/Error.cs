﻿namespace Microsoft.ProjectOxford.TextAnalytics.Contract.SentimentResponse
{
    public class Error
    {
        public string id { get; set; }
        public string message { get; set; }
    }
}