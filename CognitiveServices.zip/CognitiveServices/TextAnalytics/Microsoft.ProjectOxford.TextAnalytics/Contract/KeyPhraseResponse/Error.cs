namespace Microsoft.ProjectOxford.TextAnalytics.Contract.KeyPhraseResponse
{
    public class Error
    {
        public string id { get; set; }
        public string message { get; set; }
    }
}